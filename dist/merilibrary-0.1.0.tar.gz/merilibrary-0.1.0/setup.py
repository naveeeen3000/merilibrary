from setuptools import setup, find_packages

setup(
    name='merilibrary',
    version='0.1.0',
    description='Ye hai meri python library',
    url='/Files/Pytorch-RL',
    author='Test'
)